package com.example.mysqlxml.xml;

import java.sql.ResultSet;

public class CreateXmlFile
{
    private ResultSet rs;     //从下面的程序可以看出，此字段可省略，懒得改了，呵呵
    private String url;       //从下面的程序可以看出，此字段可省略，懒得改了，呵呵
    private Disposal disposal; //自定义的用来收集和处理数据的类
    private String root;       //xml文件的根元素名称
    private String rootchild;  //根结点的子结点的元素名称
    /**
     * @param rs : 创建xml文件所需的查询结果集
     * @param url : 指定xml文件的生成路径(包括xml文件的文件名)
     */
    public CreateXmlFile(ResultSet rs,String url)
    {
        this.rs=rs;
        this.url=url;
        disposal=new Disposal();
        disposal.setResultSet(this.rs,this.url);
    }
    //设定xml文件的根元素名称
    public void setRootElementName(String root,String rootchild)
    {
        this.root=root;
        this.rootchild=rootchild;
        disposal.setRootName(this.root,this.rootchild);
    }
    //设置属性的名字和索引位置，位置从1开始
    /**
     * @param namestring 指定属性的名称
     * @param index 指定此属性的值在查询结果集中第几个字段（字段从1开始索引）
     */
    public void setAttributeName(String namestring,int index)
    {
        disposal.collectData(namestring,index,"attribute");
    }
    //设置元素的名字和索引位置，位置从1开始
    /**
     * @param namestring 指定元素的名称
     * @param index 指定此元素的值在查询结果集中的第几个字段（字段从1开始索引）
     */
    public void setElementName(String namestring,int index)
    {
        disposal.collectData(namestring,index,"element");
    }
    /**
     * 调用此方法则立即开始创建xml文件，在属性与元素都已指派完毕后调用此方法
     */
    public void designOver()
    {
        disposal.startWrite();
    }
}
