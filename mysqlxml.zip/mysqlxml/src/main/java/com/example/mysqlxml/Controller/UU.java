package com.example.mysqlxml.Controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.mysqlxml.pojo.DBUtil;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.XMLWriter;


public class UU {


    public static void toXML(){


        Connection connection=null;
        PreparedStatement statement=null;
        ResultSet rs=null;
        connection= DBUtil.getConnection();
        String sql="SELECT * FROM  a";
        String sql1="SELECT * FROM  b";
        String sql2="SELECT * FROM  a";
        String sql3="SELECT * FROM  b";
        Document document = DocumentHelper.createDocument();
        Element root = document.addElement("dict");// 创建根节点


        try {
            statement=connection.prepareStatement(sql);
            rs=statement.executeQuery();
           PreparedStatement statement1=connection.prepareStatement(sql1);
            ResultSet rs1=statement1.executeQuery();
            PreparedStatement statement2=connection.prepareStatement(sql2);
            ResultSet rs2=statement2.executeQuery();
            PreparedStatement statement3=connection.prepareStatement(sql3);
            ResultSet rs3=statement3.executeQuery();
            int i =0;

            while(rs.next()){

                Element     word = root.addElement("Word");
                Element id1 = word.addElement("id1");
                id1.addCDATA(rs.getString("id1"));
                Element name = word.addElement("name");
                name.addCDATA(rs.getString("name"));
                Element mean=word.addElement("sex");
                mean.addCDATA(rs.getString("sex"));
                Element     b= word.addAttribute("id",i+++"");
                System.out.println(b);

                String sql4 = "update a set id='" + word.attributeValue("id") + "' where id1='" +rs.getInt("id1") + "'";
                PreparedStatement pstmt;
                    pstmt = connection.prepareStatement(sql4);
                      pstmt.executeUpdate();
            }

            while(rs1.next()){

                Element word1 = root.addElement("word1");
                Element id1 = word1.addElement("id1");
                id1.addCDATA(rs1.getString("id1"));
                Element name = word1.addElement("a_name");
                name.addCDATA(rs1.getString("a_name"));
                Element mean=word1.addElement("dizhi");
                mean.addCDATA(rs1.getString("dizhi"));



                word1.addAttribute("id",i+++"");
                String sql4 = "update b set id='" + word1.attributeValue("id") + "' where id1='" +rs1.getInt("id1") + "'";
                PreparedStatement pstmt;
                pstmt = connection.prepareStatement(sql4);
                pstmt.executeUpdate();
            }
            Element  word2 = root.addElement("weekCourseList");
            word2.addAttribute("id",i+++"");
            while(rs2.next()){

                Element name = word2.addElement("WeekCourse");

                name.addAttribute("reference",rs2.getString("id"));
            }
            while(rs3.next()){

                Element name = word2.addElement("WeekCourse1");

                name.addAttribute("reference",rs3.getString("id"));
            }

            XMLWriter writer=new XMLWriter(new FileWriter(new File("dict2.xml")));
            writer.write(document);

            writer.close();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                // 注意关闭的顺序，最后使用的最先关闭
                if (rs != null)
                    rs.close();
                if (statement!= null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        toXML();
    }

}