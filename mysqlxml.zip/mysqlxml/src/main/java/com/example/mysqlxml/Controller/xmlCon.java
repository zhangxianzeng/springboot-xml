package com.example.mysqlxml.Controller;

import com.example.mysqlxml.Service.xmlService;
import com.example.mysqlxml.pojo.DBUtil;
import com.example.mysqlxml.pojo.StringUtil;
import com.example.mysqlxml.xml.CreateXmlFile;
import org.dom4j.DocumentHelper;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@RestController
@RequestMapping("/n")
public class xmlCon{
    @Autowired
    private xmlService xmlService1;

    @RequestMapping("/k")
    public int findall() throws SQLException {
        Connection conn = DBUtil.getConnection();
        StringBuilder sb = new StringBuilder();
        sb.append("select * from U");
        PreparedStatement ptmt = conn.prepareStatement(sb.toString());
        ResultSet rs = ptmt.executeQuery();

        CreateXmlFile create = new CreateXmlFile(rs, "demo2.xml");
        create.setRootElementName("username", "username");

        create.setAttributeName("username", 1);
        create.setAttributeName("password", 2);
//        create.setElementName("username",1);
//        create.setElementName("password",2);
        create.designOver();
        return 1;
    }

    @RequestMapping("/j")
    public int addall(String filepath) throws SQLException {
        String sql = "insert into T_XML(NUMERO, REPOSICION, NOMBRE, TURNOS) values (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            //读取xml文件
           // Document doc = new SAXReader().read(new File("/Users/zhangxianzeng/Downloads/o.xml"));
            Document doc = new SAXReader().read(new File(filepath));
            //选择xml文件的节点
            List itemList = doc.selectNodes("ACCESOS/item/SOCIO");
            //遍历读出的xml中的节点
            for (Iterator iter = itemList.iterator(); iter.hasNext(); ) {
                Element el = (Element) iter.next();
                //读取节点内容
                String numero = el.elementText("NUMERO");
                String reposicion = el.elementText("REPOSICION");
                String nombre = el.elementText("NOMBRE");
                //遍历TURNOS节点中的内容
                List turnosList = el.elements("TURNOS");
                StringBuffer sbString = new StringBuffer();
                for (Iterator iter1 = turnosList.iterator(); iter1.hasNext(); ) {
                    Element turnosElt = (Element) iter1.next();
                    String lu = turnosElt.elementText("LU");
                    String ma = turnosElt.elementText("MA");
                    String mi = turnosElt.elementText("MI");
                    String ju = turnosElt.elementText("JU");
                    String vi = turnosElt.elementText("VI");
                    String sa = turnosElt.elementText("SA");
                    String doo = turnosElt.elementText("DO");
                    sbString.append(lu + "," + ma + "," + mi + "," + ju + "," + vi + "," + sa + "," + doo);
                }
                //为sql语句赋值
                pstmt.setString(1, numero);
                pstmt.setString(2, reposicion);
                pstmt.setString(3, nombre);
                pstmt.setString(4, sbString.toString());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            System.out.print("将XML导入数据库成功");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
   conn.close();
   pstmt.close();
        }


        return 1;
    }
@RequestMapping("/l")
    public void mysqlConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();//数据库驱动
            String url = "jdbc:mysql://localhost:3306/user";//数据库链接地址
            String user = "root";//用户名
            String password = "zhangxian11";//密码
            Connection conn = DriverManager.getConnection(url, user, password);//建立connection
            Statement stmt = conn.createStatement();
            conn.setAutoCommit(false);// 更改jdbc事务的默认提交方式

            String sql = "select * from a";//查询语句
            ResultSet rs = stmt.executeQuery(sql);//得到结果集
            conn.commit();//事务提交
            conn.setAutoCommit(true);// 更改jdbc事务的默认提交方式
            List<String> list=new ArrayList<String>();//创建取结果的列表，之所以使用列表，不用数组，因为现在还不知道结果有多少，不能确定数组长度，所有先用list接收，然后转为数组
            while (rs.next()) {//如果有数据，取第一列添加如list
                list.add(rs.getString(1));
            }
            if(list != null && list.size()>0){//如果list中存入了数据，转化为数组
                String[] arr=new String[list.size()];//创建一个和list长度一样的数组
                for(int i=0;i<list.size();i++){
                    arr[i]=list.get(i);//数组赋值了。
                }
                //输出数组
                for(int i=0;i<arr.length;i++){
                    System.out.println(arr[i]);
                }
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //多个表导出到xml中
    @RequestMapping("xml")
    public  void mysqlxml(){


        Connection connection=null;
        PreparedStatement statement=null;
        ResultSet rs=null;
        connection= DBUtil.getConnection();
        String sql="SELECT * FROM  a";
        String sql1="SELECT * FROM  b";
        String sql2="SELECT * FROM  a";
        String sql3="SELECT * FROM  b";
        String sql5="SELECT * FROM  c";
        String sql6="SELECT * FROM  c left join d on c.id=d.c_id";
        Document document = DocumentHelper.createDocument();
        Element root = document.addElement("dict");// 创建根节点


        try {
            statement=connection.prepareStatement(sql);
            rs=statement.executeQuery();
            PreparedStatement statement1=connection.prepareStatement(sql1);
            ResultSet rs1=statement1.executeQuery();
            PreparedStatement statement2=connection.prepareStatement(sql2);
            ResultSet rs2=statement2.executeQuery();
            PreparedStatement statement3=connection.prepareStatement(sql3);
            ResultSet rs3=statement3.executeQuery();
            PreparedStatement statement5=connection.prepareStatement(sql5);
            ResultSet rs5=statement5.executeQuery();
            PreparedStatement statement6=connection.prepareStatement(sql6);
            ResultSet rs6=statement6.executeQuery();
            int i =0;

            while(rs.next()){

                Element     word = root.addElement("Word");
                Element id1 = word.addElement("id1");
                id1.addText(StringUtil.replaceNullString(rs.getString("id1")));
                Element name = word.addElement("name");
                name.addText(StringUtil.replaceNullString(rs.getString("name")));
                Element mean=word.addElement("sex");
                mean.addText(StringUtil.replaceNullString(rs.getString("sex")));
                Element     b= word.addAttribute("id",i+++"");
                System.out.println(b);

                String sql4 = "update a set id='" + word.attributeValue("id") + "' where id1='" +rs.getInt("id1") + "'";
                PreparedStatement pstmt;
                pstmt = connection.prepareStatement(sql4);
                pstmt.executeUpdate();
            }

            while(rs1.next()){

                Element word1 = root.addElement("word1");
                Element id1 = word1.addElement("id1");
                id1.addText(StringUtil.replaceNullString(rs1.getString("id1")));
                Element name = word1.addElement("a_name");
                name.addText(StringUtil.replaceNullString(rs1.getString("a_name")));
                Element mean=word1.addElement("dizhi");
                mean.addText(StringUtil.replaceNullString(rs1.getString("dizhi")));



                word1.addAttribute("id",i+++"");
                String sql4 = "update b set id='" + word1.attributeValue("id") + "' where id1='" +rs1.getInt("id1") + "'";
                PreparedStatement pstmt;
                pstmt = connection.prepareStatement(sql4);
                pstmt.executeUpdate();
            }
            while(rs5.next()){

                Element word5 = root.addElement("Class");
                Element id5 = word5.addElement("id");
                id5.addText(StringUtil.replaceNullString(rs5.getString("id")));
                Element class1 = word5.addElement("class");
                class1.addText(StringUtil.replaceNullString(rs5.getString("class")));
                Element teacher=word5.addElement("teacher");
                teacher.addText(StringUtil.replaceNullString(rs5.getString("teacher")));
                word5.addAttribute("id",i+++"");
                String sql4 = "update c set id1='" + word5.attributeValue("id") + "' where id='" +rs5.getInt("id") + "'";
                PreparedStatement pstmt;
                pstmt = connection.prepareStatement(sql4);
                pstmt.executeUpdate();
            }

            while(rs6.next()){

                Element word6 = root.addElement("School");
                Element id6 = word6.addElement("id");
                id6.addText(StringUtil.replaceNullString(rs6.getString("d_id")));
                Element school = word6.addElement("school");
                school.addText(StringUtil.replaceNullString(rs6.getString("school")));
                Element teacher=word6.addElement("Class");
                teacher.addAttribute("reference",rs6.getString("id1"));
                word6.addAttribute("id",i+++"");
                String sql4 = "update d set id2='" + word6.attributeValue("id") + "' where d_id='" +rs6.getInt("d_id") + "'";
                PreparedStatement pstmt;
                pstmt = connection.prepareStatement(sql4);
                pstmt.executeUpdate();
            }
            Element  word2 = root.addElement("weekCourseList");
            word2.addAttribute("id",i+++"");
            while(rs2.next()){

                Element name = word2.addElement("WeekCourse");

                name.addAttribute("reference",rs2.getString("id"));
            }
            while(rs3.next()){

                Element name = word2.addElement("WeekCourse1");

                name.addAttribute("reference",rs3.getString("id"));
            }

            XMLWriter writer=new XMLWriter(new FileWriter(new File("dict3.xml")));
            writer.write(document);

            writer.close();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                // 注意关闭的顺序，最后使用的最先关闭
                if (rs != null)
                    rs.close();
                if (statement!= null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
