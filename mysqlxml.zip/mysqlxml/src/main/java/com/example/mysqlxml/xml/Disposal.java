package com.example.mysqlxml.xml;

import java.util.*;
import java.sql.*;

class Disposal
{
    private ResultSet rs;
    private String url;
    private ArrayList attrilist=new ArrayList();  //用来存储属性名和字段索引的集合类
    private ArrayList elelist=new ArrayList();    //用来存储元素名和字段索引的集合类
    private String root;
    private String rootchild;
    public void setResultSet(ResultSet rs,String url)
    {
        this.rs=rs;
        this.url=url;
    }
    public void setRootName(String root,String rootchild)
    {
        this.root=root;
        this.rootchild=rootchild;
    }
    @SuppressWarnings("unchecked")

    public void collectData(String namestring,int index,String type )
    {
        if(type.equals("attribute"))
            attrilist.add(new SaveAttrName(namestring,index));
        else
            elelist.add(new SaveEleName(namestring,index));
        //System.out.println("else");
        //System.exit(0);
    }
    public void startWrite()
    {
        new WriteXmlFile(attrilist,elelist,rs,url).create(root,rootchild);
    }
}
