package com.example.mysqlxml.Service;


import com.example.mysqlxml.dao.XmlDAo;

import com.example.mysqlxml.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class xmlServiceImpl implements xmlService{
    @Autowired
    private XmlDAo xmlDAo1;
    @Override
    public List<User> findall() {
        return xmlDAo1.findall();
    }
}
