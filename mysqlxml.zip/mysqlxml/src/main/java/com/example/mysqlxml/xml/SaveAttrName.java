package com.example.mysqlxml.xml;

public class SaveAttrName
        {
private String attributename;
private int index;
public SaveAttrName(String attributename,int index)
        {
        this.attributename=attributename;
        this.index=index;
        }
public String getAttributeName()
        {
        return attributename;
        }
public int getIndex()
        {
        return index;
        }
        }