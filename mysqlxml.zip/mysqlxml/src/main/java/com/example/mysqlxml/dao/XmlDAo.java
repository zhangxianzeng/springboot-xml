package com.example.mysqlxml.dao;

import com.example.mysqlxml.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface XmlDAo {
    List<User> findall();
}