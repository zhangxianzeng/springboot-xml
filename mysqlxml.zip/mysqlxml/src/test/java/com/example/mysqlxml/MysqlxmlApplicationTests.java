package com.example.mysqlxml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqlxmlApplicationTests {

    @Test
    void contextLoads() {
    }

}
