package com.example.mysqlxml.pojo;

public class StringUtil {
    public static String replaceNullString(String str){
        if(str == null ) return "";
        else return str;
    }
}
