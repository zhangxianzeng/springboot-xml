package com.example.mysqlxml.Controller;



import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.io.DocumentSource;


public class YY {

    public static void main(String[] args) throws Exception{
        long a = System.currentTimeMillis();
        YY cd = new YY();
        String xmlString = cd.getColumnXml();

        cd.stringToXml(xmlString);

        System.out.println(System.currentTimeMillis()-a);
    }
    /**
     * 描述：生成xml文件
     * @param xmlString
     * @throws Exception
     */
    public void stringToXml(String xmlString) throws Exception {
        Document resDoc = DocumentHelper.parseText(xmlString);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        DocumentSource source = new DocumentSource(resDoc);
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        //设置文档的换行与缩进
        transformer.setOutputProperty(OutputKeys.INDENT, "YES");
        //设置日期格式
        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddHHmmss");
        String resFile = "/Users/zhangxianzeng/Downloads/11.xml";
        StreamResult result = new StreamResult(new File(resFile));
        transformer.transform(source,result);
    }

    /**
     * 描述：获取栏目数据并转化为xml字符串
     * @return
     */
    public String getColumnXml() {
        Connection con = null;// 创建一个数据库连接
        PreparedStatement pre = null;// 创建预编译语句对象
        ResultSet rs = null;// 创建一个结果集对象
        StringBuffer xmlString = new StringBuffer();
        xmlString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\t" + "\r\n"  +"<!DOCTYPE book [<!ENTITY nbsp \" \"><!ENTITY copy \"©\"><!ENTITY reg \"®\"><!ENTITY trade \"™\"><!ENTITY mdash \"—\"><!ENTITY ldquo \"“\"><!ENTITY rdquo \"”\"><!ENTITY pound \"£\"><!ENTITY yen \"¥\"><!ENTITY euro \"€\">]>"  + "\r\n" + "<book>"  + "\r\n"+"\t");
        xmlString.append("<edition>1.0</edition>"  + "\r\n" + "\t");
        xmlString.append("<copyright>大汉网络</copyright>"  + "\r\n" + "\t");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");// 加载mysql驱动程序
            String url = "jdbc:mysql://127.0.0.1:3306/user";
            //String url = "jdbc:mysql://10.25.1.2:3306/isp_gjj_zs?allowMultiQueries=true&useUnicode=true&characterEncoding=utf8";
            con = DriverManager.getConnection(url, "root",  "zhangxian11");// 获取连接

            String sql = "SELECT * from b";// 预编译语句
            String sql1 = "SELECT * from a";
            con.setAutoCommit(false);
            pre = con.prepareStatement(sql);// 实例化预编译语句
            rs = pre.executeQuery();// 执行查询
            PreparedStatement  pre1=con.prepareStatement(sql1);
            ResultSet rs1=pre1.executeQuery();
            con.commit();
            StringBuffer article = new StringBuffer();
            int i=0;
            while(rs.next()) {
                article.append( "<article>"  + "\r\n" + "\t\t");
                article.append("<a_name>" + rs.getString("a_name") +"</a_name>"  + "\r\n" + "\t\t");
                article.append("<dizhi>" + rs.getString("dizhi") + "</dizhi>"  + "\r\n" + "\t\t");


                if(!rs.isLast()) {
                    article.append( "</article>"  + "\r\n" + "\t");
                }else {
                    article.append( "</article>"  + "\r\n" );
                }
            }
            while(rs1.next()) {
                article.append( "<article1>"  + "\r\n" + "\t\t");
                article.append("<name>" + rs1.getString("name") +"</name>"  + "\r\n" + "\t\t");
                article.append("<sex>" + rs1.getString("sex") + "</sex>"  + "\r\n" + "\t\t");


                if(!rs1.isLast()) {
                    article.append( "</article1>"  + "\r\n" + "\t");
                }else {
                    article.append( "</article1>"  + "\r\n" );
                }
            }

            xmlString.append( article.toString() + "</book>"  + "\t" );
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                // 注意关闭的顺序，最后使用的最先关闭
                if (rs != null)
                    rs.close();
                if (pre != null)
                    pre.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return xmlString.toString();
    }


}

