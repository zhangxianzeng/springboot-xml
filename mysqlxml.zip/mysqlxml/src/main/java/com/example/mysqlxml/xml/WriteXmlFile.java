package com.example.mysqlxml.xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;

public class WriteXmlFile
{
    private ResultSet rs;
    private String url;
    private ArrayList attrilist;
    private ArrayList elelist;
    public WriteXmlFile(ArrayList attrilist,ArrayList elelist,ResultSet rs,String url)
    {
        this.attrilist=attrilist;
        this.elelist=elelist;
        this.rs=rs;
        this.url=url;
    }
    /**
     * @param root : xml文件的根元素名
     */
    public void create(String root,String rootchild)
    {
        DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();

        Document doc=null;
        try
        {
            DocumentBuilder db = dbf.newDocumentBuilder();
            doc = db.newDocument();
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        Element rootelement=doc.createElement(root);
        doc.appendChild(rootelement);
        Iterator attri=attrilist.iterator();
        Iterator ele=elelist.iterator();
        //System.out.println("iterator");
        try
        {
            while(rs.next())
            {
                Element rootchildelement=doc.createElement(rootchild);
                //System.out.println("while");
                while(attri.hasNext())
                {
                    /**
                     *  循环到属性集合中取元素名称，之后从查询结果集中取得数据，创建元素属性
                     */
                    SaveAttrName temp=(SaveAttrName)attri.next();
                    rootchildelement.setAttribute(temp.getAttributeName(),rs.getString(temp.getIndex()).trim());
                }
                rootelement.appendChild(rootchildelement);
                while(ele.hasNext())
                {
                    /**
                     *  循环到元素集合中取元素名称，之后从查询结果集中取得数据，创建结点
                     */
                    SaveEleName temp=(SaveEleName)ele.next();
                    Element tempelement=doc.createElement(temp.getElementName());
                    Text temptextelement=doc.createTextNode(rs.getString(temp.getIndex()).trim());
                    tempelement.appendChild(temptextelement);
                    rootchildelement.appendChild(tempelement);
                }
                attri=attrilist.iterator(); //重复循环到集合中取值，下同
                ele=elelist.iterator();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        writeXml(doc);
    }
    public static void callWriteXmlFile(Document doc, Writer w, String encoding) {
        try {
            // Prepare the DOM document for writing
            Source source = new DOMSource(doc);

            // Prepare the output file
            Result result = new StreamResult(w);

            // Write the DOM document to the file
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.setOutputProperty(OutputKeys.ENCODING, encoding);
            xformer.transform(source, result);
        }
        catch (TransformerConfigurationException e) {
            e.printStackTrace();
}
catch (TransformerException e) { e.printStackTrace();
 }
 }
    private void writeXml(Document doc)
    {
        try
        {
            FileOutputStream outStream = new FileOutputStream(url);
            OutputStreamWriter outWriter = new OutputStreamWriter(outStream);
            callWriteXmlFile(doc, outWriter, "GB2312");
            outWriter.close();
            outStream.close();
            System.out.print("\nWrite xmlfileåå successful!\n");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}