package com.example.mysqlxml.xml;

public class SaveEleName
{
    private String elementname;
    private int index;
    public SaveEleName(String elementname,int index)
    {
        this.elementname=elementname;
        this.index=index;
    }
    public String getElementName()
    {
        return elementname;
    }
    public int getIndex()
    {
        return index;
    }
}