package com.example.mysqlxml.Service;

import com.example.mysqlxml.pojo.User;

import java.util.List;

public interface xmlService {
    List<User> findall();
}
