package com.example.mysqlxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlxmlApplication {

    public static void main(String[] args) {
        SpringApplication.run(MysqlxmlApplication.class, args);
    }

}
